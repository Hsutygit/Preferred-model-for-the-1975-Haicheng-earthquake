% plot_rupture_process.m

clc; clear;

%% Parameters
MinR = 160;
CFL  = 0.98;
Vp   = 6000;
det_t = CFL * MinR / Vp;  

%% Paths
result_dir = '.\r=1.30_Dc=0.20_mud=0.269_mus=0.570_S=0.80_pore_pressure=5_Mw=6.85\';
grid_dir   = '.\Grid\';

%% Load grid
load([grid_dir, 'triangle.mat']);   % -> t  (element connectivity, n_ele × 3)
load([grid_dir, 'nodes.mat']);      % -> p  (node coordinates, n_node × 3)

p(:,3) = p(:,3)-5;
%% Load data
load([result_dir, 'rate.mat']);         % -> rate_cpu
load([result_dir, 'moment.mat']);       % -> moment_cpu
load([result_dir, 'slip_out.mat']);     % -> slip_out   (T × maxtime)
load([result_dir, 'moment_rate.mat']);  % -> moment_rate (N×2: [time, value])

% Gather GPU arrays if needed
rate        = gather(rate_cpu);
moment      = gather(moment_cpu);
try; slip_out    = gather(slip_out);    catch; end
try; moment_rate = gather(moment_rate); catch; end

stepnum = size(rate, 2);           % total number of time steps

%% Extract final slip (last column) and STF components
final_slip = slip_out(:, end);     % cumulative slip at final timestep

% moment_rate = [time_vec, moment_rate_value]  (cal_rupture_GPU_for_opt.m line 497)
t_mr    = moment_rate(:, 1);       % time axis [s]
mr_vals = moment_rate(:, 2);       % moment rate [N·m/s]

%% Time settings — 15 snapshots, 0.75 s interval
time_interval = 0.75;               % 0.75 second per snapshot
n_snaps       = 15;
snap_times    = time_interval * (1:n_snaps);   % [0.75, 1.5, ..., 11.25]
snap_steps    = round(snap_times / det_t);
snap_steps(snap_steps > stepnum) = stepnum;

%% Color limits for slip rate (from plot_mv_h550.m)
clim_rate = [0, 4.5];

%% Highlight element indices
n_elem = size(t, 1);
highlight_idx = intersect(2707:4010, 1:n_elem);  % ensure valid indices

% Bounding box for highlighted elements (for zoomed-in isolated view)
highlight_nodes_all = t(highlight_idx, 1:3);
highlight_nodes_all = highlight_nodes_all(:);
highlight_nodes_all(highlight_nodes_all <= 0) = [];  % remove any zero-padding
highlight_nodes_idx = unique(highlight_nodes_all);
hl_p = p(highlight_nodes_idx, :);
hl_ax_lim = [min(hl_p(:,1)), max(hl_p(:,1)), ...
             min(hl_p(:,2)), max(hl_p(:,2)), -17, -5];

%% ========================================================================
%  Create figure: 4 rows × 5 columns
%  Rows 1–3: 15 rupture process snapshots (5 per row, 0.75 s interval)
%  Row 4:    col 1-2 = final slip (all), col 3-4 = 2707:4010 only, col 5 = STF
%  ========================================================================
figure('color', 'white', 'Position', [40, 20, 1500, 900]);

% --- Shared view angle and axis limits for 3D fault plots ---
view_ang = [11, 30];   % from plot_mv_h550.m
ax_lim   = [min(p(:,1)), max(p(:,1)), min(p(:,2)), max(p(:,2)), -17, -5];

%% ---- Rows 1–3: Rupture Process (15 snapshots, 5 per row) ----
for i = 1:n_snaps
    subplot(4, 5, i);

    k = snap_steps(i);
    cdata = rate(:, k);

    patch('Faces', t(:, 1:3), 'Vertices', p, ...
          'FaceColor', 'flat', 'FaceVertexCData', cdata, ...
          'CDataMapping', 'scaled', 'EdgeColor', 'none');

    caxis(clim_rate);
    view(view_ang);
    axis equal;
    axis(ax_lim);
    axis off;

    % Only show time label
    if snap_times(i) == round(snap_times(i))
        title(sprintf('%d s', snap_times(i)), ...
              'FontName', 'Times New Roman', 'FontSize', 15);
    else
        title(sprintf('%.2f s', snap_times(i)), ...
              'FontName', 'Times New Roman', 'FontSize', 15);
    end

    camlight('headlight');
    colormap(whitejet);
end

% Vertical colorbar on the right side of rupture process panels
hcb_rate = colorbar;
hcb_rate.Position = [0.915866666666667,0.474401008827238,0.008533333333333,0.413619167717527];
hcb_rate.FontSize = 15;
hcb_rate.FontName = 'Times New Roman';
title(hcb_rate, 'slip rate (m/s)');
caxis(clim_rate);
colormap(whitejet);

%% ---- Bottom Row: Final Slip Distribution + STF ----
% Use manual axes: left 50% = two slip panels, right 50% = STF

% = = = = Panel 1: All elements, slip distribution = = = =
ax1 = axes('Position', [0.1, 0.07, 0.21, 0.21]);

patch('Faces', t(:, 1:3), 'Vertices', p, ...
      'FaceColor', 'flat', 'FaceVertexCData', final_slip, ...
      'CDataMapping', 'scaled', 'EdgeColor', 'none');

caxis([0, max(final_slip)]);


view(-23,23);
axis equal;
axis(ax_lim);

camlight('headlight');
colormap(whitejet);
set(gca, 'FontName', 'Times New Roman', 'FontSize', 15);

% = = = = Panel 2: Only elements 2707:4010 = = = =
ax2 = axes('Position', [0.275, 0.07, 0.21, 0.21]);

patch('Faces', t(highlight_idx, 1:3), 'Vertices', p, ...
      'FaceColor', 'flat', 'FaceVertexCData', final_slip(highlight_idx), ...
      'CDataMapping', 'scaled', 'EdgeColor', 'none');

caxis([0, max(final_slip)]);
view(42,23);
axis equal;
axis(hl_ax_lim);


camlight('headlight');
colormap(whitejet);
set(gca, 'FontName', 'Times New Roman', 'FontSize', 15);

% Colorbar for slip, placed between panel 2 and STF
hcb_slip = colorbar;
hcb_slip.Position = [0.476333333333332,0.03656998738966,0.009666666666667,0.274401008827238];
hcb_slip.FontSize = 15;
hcb_slip.FontName = 'Times New Roman';
title(hcb_slip, 'slip (m)');

% = = = = Panel 3: Source Time Function (pink fill), right 50% = = = =
ax3 = axes('Position', [0.6, 0.07, 0.30, 0.21]);

% Restrict to 0–12 s
stf_time = 12;
idx_stf = t_mr <= stf_time;
t_plot = t_mr(idx_stf);
mr_plot = mr_vals(idx_stf);

% Filled area in pink
fill([t_plot(1); t_plot; t_plot(end)], [0; mr_plot; 0], ...
     [1, 0.75, 0.80], 'EdgeColor', 'k', 'LineWidth', 1.2);

xlabel('Time (s)', 'FontSize', 12);
ylabel('Moment rate (N·m/s)', 'FontSize', 12);
xlim([0, stf_time]);
set(gca, 'LineWidth', 1.2, 'FontSize', 15);
box off;
grid on;

%% Save figure
print(gcf, 'Rupture_Process_Summary.png', '-dpng', '-r300');
